USE cl205345;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    primeiro_nome VARCHAR(50) NOT NULL,
    segundo_nome VARCHAR(50) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    is_admin TINYINT(1) DEFAULT 0,
    possui_plano TINYINT(1) DEFAULT 0,
    nome_plano VARCHAR(50) DEFAULT 'Nenhum plano',
    data_vencimento DATE NULL,
    data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS acessos_diarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hora INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
    data_registro DATE NOT NULL,
    UNIQUE KEY idx_data_hora (data_registro, hora)
);

INSERT INTO usuarios (primeiro_nome, segundo_nome, cpf, email, senha, is_admin, possui_plano, nome_plano, data_vencimento) VALUES
('Ariely', 'Vitória', '123.456.789-00', 'admin@librastech.com', '$2a$10$X813U4oQ2gP/.Csk38OAtOn/IeHQ92R41E4YpT7.a5B6lVf8VLOtK', 1, 1, 'Plano Dev Pro', '2026-11-25'),
('Ana', 'Beatriz', '234.567.890-11', 'ana.beatriz@gmail.com', '$2a$10$X813U4oQ2gP/.Csk38OAtOn/IeHQ92R41E4YpT7.a5B6lVf8VLOtK', 0, 1, 'Plano Anual Premium', '2027-03-10'),
('Lucas', 'Mendes', '345.678.901-22', 'lucas.mendes@hotmail.com', '$2a$10$X813U4oQ2gP/.Csk38OAtOn/IeHQ92R41E4YpT7.a5B6lVf8VLOtK', 0, 0, 'Nenhum plano', NULL),
('Fernanda', 'Silva', '456.789.012-33', 'fernanda.silva@outlook.com', '$2a$10$X813U4oQ2gP/.Csk38OAtOn/IeHQ92R41E4YpT7.a5B6lVf8VLOtK', 0, 1, 'Plano Mensal Básico', '2026-11-20'),
('Roberto', 'Almeida', '567.890.123-44', 'roberto.almeida@yahoo.com', '$2a$10$X813U4oQ2gP/.Csk38OAtOn/IeHQ92R41E4YpT7.a5B6lVf8VLOtK', 0, 0, 'Nenhum plano', NULL);

-- Credenciais iniciais de acesso (o main.js gera o hash real automaticamente ao iniciar):
-- E-mail: admin@librastech.com
-- Senha: 123456