document.addEventListener('DOMContentLoaded', async () => {
  const btnNavDashboard = document.querySelector('#btnNavDashboard');
  const btnNavMinhaConta = document.querySelector('#btnNavMinhaConta');
  const btnSair = document.querySelector('#btnSair');
  const nomeAdmin = document.querySelector('#nomeAdmin');
  const emailAdmin = document.querySelector('#emailAdmin');
  const avatarLetra = document.querySelector('#avatarLetra');

  const tbodyUsuarios = document.querySelector('#tbodyUsuarios');
  const inputPesquisa = document.querySelector('#inputPesquisa');
  const btnAtualizarTabela = document.querySelector('#btnAtualizarTabela');
  const estadoVazio = document.querySelector('#estadoVazio');
  const estadoCarregando = document.querySelector('#estadoCarregando');
  const infoPaginacao = document.querySelector('#infoPaginacao');
  const alertaFeedback = document.querySelector('#alertaFeedback');

  // Inputs de data (cadastro e edição)
  const novoVencimento = document.querySelector('#novoVencimento');
  const editVencimento = document.querySelector('#editVencimento');

  // Elementos do Modal de Cadastro
  const btnAbrirModalNovo = document.querySelector('#btnAbrirModalNovo');
  const modalNovoEl = document.querySelector('#modalNovoUsuario');
  const modalNovo = (modalNovoEl && window.bootstrap) ? new bootstrap.Modal(modalNovoEl) : null;
  const formNovoUsuario = document.querySelector('#formNovoUsuario');
  const novoPrimeiroNome = document.querySelector('#novoPrimeiroNome');
  const novoSegundoNome = document.querySelector('#novoSegundoNome');
  const novoCpf = document.querySelector('#novoCpf');
  const novoEmail = document.querySelector('#novoEmail');
  const novoSenha = document.querySelector('#novoSenha');
  const novoPossuiPlano = document.querySelector('#novoPossuiPlano');
  const novoNomePlano = document.querySelector('#novoNomePlano');
  const alertaModalNovo = document.querySelector('#alertaModalNovo');

  // Elementos do Modal de Edição
  const modalEditarEl = document.querySelector('#modalEditarUsuario');
  const modalEditar = (modalEditarEl && window.bootstrap) ? new bootstrap.Modal(modalEditarEl) : null;
  const formEditarUsuario = document.querySelector('#formEditarUsuario');
  const editUserId = document.querySelector('#editUserId');
  const editPrimeiroNome = document.querySelector('#editPrimeiroNome');
  const editSegundoNome = document.querySelector('#editSegundoNome');
  const editCpf = document.querySelector('#editCpf');
  const editEmail = document.querySelector('#editEmail');
  const editNovaSenha = document.querySelector('#editNovaSenha');
  const editPossuiPlano = document.querySelector('#editPossuiPlano');
  const editNomePlano = document.querySelector('#editNomePlano');
  const alertaModalEditar = document.querySelector('#alertaModalEditar');

  // Elementos do Modal de Exclusão
  const modalExcluirEl = document.querySelector('#modalExcluir');
  const modalExcluir = (modalExcluirEl && window.bootstrap) ? new bootstrap.Modal(modalExcluirEl) : null;
  const nomeExcluir = document.querySelector('#nomeExcluir');
  const btnConfirmarExcluir = document.querySelector('#btnConfirmarExcluir');
  let usuarioParaExcluir = null;

  // Configuração e utilitários de vencimento
  const DIAS_ALERTA_VENCIMENTO = 15;

  function normalizarDataISO(valor) {
    if (!valor) return null;
    if (typeof valor === 'string') return valor.slice(0, 10);
    try {
      return new Date(valor).toISOString().slice(0, 10);
    } catch {
      return null;
    }
  }

  function formatarDataBR(iso) {
    if (!iso) return '-';
    const partes = iso.split('-');
    if (partes.length !== 3) return iso;
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
  }

  function calcularStatusVencimento(possuiPlano, dataVencimento) {
    if (Number(possuiPlano) !== 1) {
      return { classeLinha: '', classeBadge: 'sem', textoPrincipal: 'Sem plano', textoSecundario: '' };
    }

    const iso = normalizarDataISO(dataVencimento);
    if (!iso) {
      return { classeLinha: '', classeBadge: 'ok', textoPrincipal: 'Sem vencimento', textoSecundario: 'Plano ativo' };
    }

    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    const [ano, mes, dia] = iso.split('-').map(Number);
    const dataAlvo = new Date(ano, mes - 1, dia);
    dataAlvo.setHours(0, 0, 0, 0);

    const diffMs = dataAlvo.getTime() - hoje.getTime();
    const diffDias = Math.round(diffMs / (1000 * 60 * 60 * 24));
    const dataFormatada = formatarDataBR(iso);

    if (diffDias < 0) {
      const atraso = Math.abs(diffDias);
      return {
        classeLinha: 'linha-vencida',
        classeBadge: 'vencido',
        textoPrincipal: dataFormatada,
        textoSecundario: atraso === 1 ? 'Vencido há 1 dia' : `Vencido há ${atraso} dias`
      };
    }

    if (diffDias <= DIAS_ALERTA_VENCIMENTO) {
      let textoPrazo = `Vence em ${diffDias} dias`;
      if (diffDias === 0) textoPrazo = 'Vence hoje!';
      else if (diffDias === 1) textoPrazo = 'Vence amanhã';

      return {
        classeLinha: 'linha-alerta-vencimento',
        classeBadge: 'alerta',
        textoPrincipal: dataFormatada,
        textoSecundario: textoPrazo
      };
    }

    return {
      classeLinha: '',
      classeBadge: 'ok',
      textoPrincipal: dataFormatada,
      textoSecundario: `Em dia (${diffDias} dias)`
    };
  }

  // Navegação da Sidebar
  if (btnNavDashboard) {
    btnNavDashboard.addEventListener('click', () => window.api.navegarPara('frmPrincipal.html'));
  }
  if (btnNavMinhaConta) {
    btnNavMinhaConta.addEventListener('click', () => window.api.navegarPara('frmMeusDados.html'));
  }
  if (btnSair) {
    btnSair.addEventListener('click', () => window.api.logout());
  }
  if (btnAtualizarTabela) {
    btnAtualizarTabela.addEventListener('click', () => carregarUsuarios());
  }

  // Carregar dados do administrador logado na Sidebar
  try {
    const user = await window.api.obterUsuarioLogado();
    if (user) {
      if (nomeAdmin) nomeAdmin.textContent = `${user.primeiro_nome} ${user.segundo_nome}`;
      if (emailAdmin) emailAdmin.textContent = user.email;
      if (avatarLetra) avatarLetra.textContent = user.primeiro_nome.charAt(0).toUpperCase();
    }
  } catch (err) {
    console.error('Erro ao obter usuário logado:', err);
  }

  // Sincronizar seleção de planos e vencimento no Cadastro
  if (novoPossuiPlano && novoNomePlano) {
    novoPossuiPlano.addEventListener('change', () => {
      const temPlano = novoPossuiPlano.value === '1';
      if (!temPlano) {
        novoNomePlano.value = 'Nenhum plano';
        novoNomePlano.disabled = true;
        if (novoVencimento) {
          novoVencimento.value = '';
          novoVencimento.disabled = true;
        }
      } else {
        novoNomePlano.disabled = false;
        if (novoNomePlano.value === 'Nenhum plano') {
          novoNomePlano.value = 'Plano Mensal Básico';
        }
        if (novoVencimento) {
          novoVencimento.disabled = false;
        }
      }
    });
  }

  // Sincronizar seleção de planos e vencimento na Edição
  if (editPossuiPlano && editNomePlano) {
    editPossuiPlano.addEventListener('change', () => {
      const temPlano = editPossuiPlano.value === '1';
      if (!temPlano) {
        editNomePlano.value = 'Nenhum plano';
        editNomePlano.disabled = true;
        if (editVencimento) {
          editVencimento.value = '';
          editVencimento.disabled = true;
        }
      } else {
        editNomePlano.disabled = false;
        if (editNomePlano.value === 'Nenhum plano') {
          editNomePlano.value = 'Plano Mensal Básico';
        }
        if (editVencimento) {
          editVencimento.disabled = false;
        }
      }
    });
  }

  // Abrir Modal de Cadastro
  if (btnAbrirModalNovo) {
    btnAbrirModalNovo.addEventListener('click', () => {
      if (!modalNovo) {
        exibirFeedback('Não foi possível abrir o formulário de cadastro.', 'danger');
        return;
      }
      formNovoUsuario.reset();
      alertaModalNovo.classList.add('d-none');
      novoPossuiPlano.value = '0';
      novoNomePlano.value = 'Nenhum plano';
      novoNomePlano.disabled = true;
      if (novoVencimento) {
        novoVencimento.value = '';
        novoVencimento.disabled = true;
      }
      modalNovo.show();
    });
  }

  // Submeter Cadastro de Novo Usuário
  if (formNovoUsuario) {
    formNovoUsuario.addEventListener('submit', async (e) => {
      e.preventDefault();
      alertaModalNovo.classList.add('d-none');

      const temPlano = novoPossuiPlano.value === '1';
      const payload = {
        primeiro_nome: novoPrimeiroNome.value.trim(),
        segundo_nome: novoSegundoNome.value.trim(),
        cpf: novoCpf.value.trim(),
        email: novoEmail.value.trim(),
        senha: novoSenha.value,
        possui_plano: temPlano,
        nome_plano: temPlano ? novoNomePlano.value : 'Nenhum plano',
        data_vencimento: (temPlano && novoVencimento && novoVencimento.value) ? novoVencimento.value : null
      };

      try {
        const res = await window.api.adicionarUsuario(payload);
        if (res && res.sucesso) {
          if (modalNovo) modalNovo.hide();
          exibirFeedback(res.mensagem || 'Usuário cadastrado com sucesso!', 'success');
          await carregarUsuarios();
        } else {
          alertaModalNovo.textContent = (res && res.mensagem) || 'Erro ao cadastrar usuário.';
          alertaModalNovo.classList.remove('d-none');
        }
      } catch (err) {
        alertaModalNovo.textContent = 'Erro de comunicação ao cadastrar usuário.';
        alertaModalNovo.classList.remove('d-none');
      }
    });
  }

  // Submeter Edição de Usuário
  if (formEditarUsuario) {
    formEditarUsuario.addEventListener('submit', async (e) => {
      e.preventDefault();
      alertaModalEditar.classList.add('d-none');

      const temPlano = editPossuiPlano.value === '1';
      const payload = {
        id: editUserId.value,
        primeiro_nome: editPrimeiroNome.value.trim(),
        segundo_nome: editSegundoNome.value.trim(),
        cpf: editCpf.value.trim(),
        email: editEmail.value.trim(),
        nova_senha: editNovaSenha.value,
        possui_plano: temPlano,
        nome_plano: temPlano ? editNomePlano.value : 'Nenhum plano',
        data_vencimento: (temPlano && editVencimento && editVencimento.value) ? editVencimento.value : null
      };

      try {
        const res = await window.api.atualizarUsuario(payload);
        if (res && res.sucesso) {
          if (modalEditar) modalEditar.hide();
          exibirFeedback(res.mensagem || 'Usuário atualizado com sucesso!', 'success');
          await carregarUsuarios();
        } else {
          alertaModalEditar.textContent = (res && res.mensagem) || 'Erro ao atualizar usuário.';
          alertaModalEditar.classList.remove('d-none');
        }
      } catch (err) {
        alertaModalEditar.textContent = 'Erro de comunicação ao atualizar usuário.';
        alertaModalEditar.classList.remove('d-none');
      }
    });
  }

  // Confirmar Exclusão de Usuário
  if (btnConfirmarExcluir) {
    btnConfirmarExcluir.addEventListener('click', async () => {
      if (!usuarioParaExcluir) return;

      try {
        const res = await window.api.excluirUsuario(usuarioParaExcluir.id);
        if (modalExcluir) modalExcluir.hide();

        if (res && res.sucesso) {
          exibirFeedback(res.mensagem || 'Usuário excluído com sucesso!', 'success');
          await carregarUsuarios();
        } else {
          exibirFeedback((res && res.mensagem) || 'Erro ao excluir usuário.', 'danger');
        }
      } catch (err) {
        if (modalExcluir) modalExcluir.hide();
        exibirFeedback('Erro de comunicação ao excluir usuário.', 'danger');
      } finally {
        usuarioParaExcluir = null;
      }
    });
  }

  // Filtro de Pesquisa
  if (inputPesquisa) {
    let timeoutPesquisa = null;
    inputPesquisa.addEventListener('input', () => {
      clearTimeout(timeoutPesquisa);
      timeoutPesquisa = setTimeout(() => {
        carregarUsuarios();
      }, 300);
    });
  }

  // Carrega a tabela ao abrir a página
  await carregarUsuarios();

  async function carregarUsuarios() {
    setCarregando(true);
    if (tbodyUsuarios) tbodyUsuarios.replaceChildren();

    try {
      const termo = inputPesquisa ? inputPesquisa.value.trim() : '';
      const res = await window.api.listarUsuarios({ busca: termo });

      if (res && res.sucesso && Array.isArray(res.usuarios)) {
        renderizarTabela(res.usuarios);
      } else {
        renderizarTabela([]);
        if (res && res.mensagem) {
          exibirFeedback(res.mensagem, 'danger');
        }
      }
    } catch (err) {
      console.error('Erro ao carregar usuários:', err);
      renderizarTabela([]);
      exibirFeedback('Erro ao carregar a lista de usuários.', 'danger');
    } finally {
      setCarregando(false);
    }
  }

  function renderizarTabela(usuarios) {
    if (!tbodyUsuarios) return;
    tbodyUsuarios.replaceChildren();

    if (usuarios.length === 0) {
      if (estadoVazio) estadoVazio.classList.remove('d-none');
      if (infoPaginacao) infoPaginacao.textContent = 'Exibindo 0 registros';
      return;
    }

    if (estadoVazio) estadoVazio.classList.add('d-none');
    if (infoPaginacao) infoPaginacao.textContent = `Exibindo ${usuarios.length} registros`;

    usuarios.forEach(u => {
      const statusVenc = calcularStatusVencimento(u.possui_plano, u.data_vencimento);

      const tr = document.createElement('tr');
      if (statusVenc.classeLinha) {
        tr.classList.add(statusVenc.classeLinha);
      }

      // Primeiro Nome
      const tdPrimeiroNome = document.createElement('td');
      tdPrimeiroNome.className = 'ps-4 fw-semibold';
      tdPrimeiroNome.textContent = u.primeiro_nome;
      tr.appendChild(tdPrimeiroNome);

      // Segundo Nome
      const tdSegundoNome = document.createElement('td');
      tdSegundoNome.textContent = u.segundo_nome;
      tr.appendChild(tdSegundoNome);

      // CPF
      const tdCpf = document.createElement('td');
      tdCpf.textContent = u.cpf;
      tr.appendChild(tdCpf);

      // E-mail
      const tdEmail = document.createElement('td');
      tdEmail.textContent = u.email;
      tr.appendChild(tdEmail);

      // Senha Cadastrada
      const tdSenha = document.createElement('td');
      const badgeSenha = document.createElement('span');
      badgeSenha.className = 'badge bg-light text-muted border';
      badgeSenha.textContent = 'Senha cadastrada';
      tdSenha.appendChild(badgeSenha);
      tr.appendChild(tdSenha);

      // Possui Plano?
      const tdPossuiPlano = document.createElement('td');
      const badgePlano = document.createElement('span');
      if (Number(u.possui_plano) === 1) {
        badgePlano.className = 'badge-plano-ativo';
        badgePlano.textContent = 'Sim';
      } else {
        badgePlano.className = 'badge-plano-inativo';
        badgePlano.textContent = 'Não';
      }
      tdPossuiPlano.appendChild(badgePlano);
      tr.appendChild(tdPossuiPlano);

      // Qual Plano?
      const tdQualPlano = document.createElement('td');
      tdQualPlano.textContent = u.nome_plano || 'Nenhum plano';
      tr.appendChild(tdQualPlano);

      // Vencimento
      const tdVencimento = document.createElement('td');
      const badgeVenc = document.createElement('span');
      badgeVenc.className = `badge-vencimento ${statusVenc.classeBadge}`;
      badgeVenc.textContent = statusVenc.textoPrincipal;
      tdVencimento.appendChild(badgeVenc);

      if (statusVenc.textoSecundario) {
        const spanDias = document.createElement('span');
        spanDias.className = 'dias-restantes';
        spanDias.textContent = statusVenc.textoSecundario;
        tdVencimento.appendChild(spanDias);
      }
      tr.appendChild(tdVencimento);

      // Ações (Editar e Excluir)
      const tdAcoes = document.createElement('td');
      tdAcoes.className = 'text-center text-nowrap';

      const btnEditar = document.createElement('button');
      btnEditar.type = 'button';
      btnEditar.className = 'btn btn-sm btn-outline-primary me-1';
      btnEditar.innerHTML = '<i class="fa-regular fa-pen-to-square me-1"></i> Editar';
      btnEditar.title = 'Editar Usuário';
      btnEditar.addEventListener('click', () => abrirEdicao(u.id));

      const btnExcluir = document.createElement('button');
      btnExcluir.type = 'button';
      btnExcluir.className = 'btn btn-sm btn-outline-danger';
      btnExcluir.innerHTML = '<i class="fa-regular fa-trash-can"></i>';
      btnExcluir.title = 'Excluir Usuário';
      btnExcluir.addEventListener('click', () => abrirConfirmacaoExclusao(u));

      tdAcoes.appendChild(btnEditar);
      tdAcoes.appendChild(btnExcluir);
      tr.appendChild(tdAcoes);

      tbodyUsuarios.appendChild(tr);
    });
  }

  async function abrirEdicao(id) {
    if (!modalEditar) {
      exibirFeedback('Não foi possível abrir o modal de edição.', 'danger');
      return;
    }

    alertaModalEditar.classList.add('d-none');
    editNovaSenha.value = '';

    try {
      const res = await window.api.buscarUsuarioPorId(id);
      if (res && res.sucesso && res.usuario) {
        const u = res.usuario;
        const temPlano = Number(u.possui_plano) === 1;

        editUserId.value = u.id;
        editPrimeiroNome.value = u.primeiro_nome;
        editSegundoNome.value = u.segundo_nome;
        editCpf.value = u.cpf;
        editEmail.value = u.email;
        editPossuiPlano.value = temPlano ? '1' : '0';
        editNomePlano.value = u.nome_plano || 'Nenhum plano';
        editNomePlano.disabled = !temPlano;

        if (editVencimento) {
          editVencimento.value = temPlano ? (normalizarDataISO(u.data_vencimento) || '') : '';
          editVencimento.disabled = !temPlano;
        }

        modalEditar.show();
      } else {
        exibirFeedback('Não foi possível carregar os dados do usuário.', 'danger');
      }
    } catch (err) {
      exibirFeedback('Erro ao buscar detalhes do usuário.', 'danger');
    }
  }

  function abrirConfirmacaoExclusao(usuario) {
    if (!modalExcluir) return;
    usuarioParaExcluir = usuario;
    if (nomeExcluir) {
      nomeExcluir.textContent = `${usuario.primeiro_nome} ${usuario.segundo_nome} (${usuario.email})`;
    }
    modalExcluir.show();
  }

  function setCarregando(carregando) {
    if (carregando) {
      if (estadoCarregando) estadoCarregando.classList.remove('d-none');
      if (estadoVazio) estadoVazio.classList.add('d-none');
    } else {
      if (estadoCarregando) estadoCarregando.classList.add('d-none');
    }
  }

  function exibirFeedback(msg, tipo) {
    if (!alertaFeedback) return;
    alertaFeedback.textContent = msg;
    alertaFeedback.className = `alert alert-${tipo} py-2 px-3 mb-3`;
    alertaFeedback.classList.remove('d-none');
    setTimeout(() => alertaFeedback.classList.add('d-none'), 4000);
  }
});