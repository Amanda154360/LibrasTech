# LibrasTech Desktop — Painel Administrativo

Aplicação desktop desenvolvida em **Electron** para administração e acompanhamento de métricas da plataforma **LibrasTech**. Permite o controle de usuários, gerenciamento de planos e datas de vencimento, edição de dados cadastrais e visualização de indicadores em tempo real.

---

## Tecnologias Utilizadas

- **Electron** (Processo Principal e Renderização com `contextIsolation` e `sandbox`)
- **Node.js** (CommonJS — `require` / `module.exports`)
- **HTML5, CSS3 e Bootstrap 5** (Interface responsiva e componentes visuais)
- **JavaScript Puro (ES6+)** (Manipulação segura do DOM)
- **Chart.js** (Gráficos interativos no Dashboard)
- **MySQL (`mysql2/promise`)** (Persistência de dados com queries parametrizadas)
- **Bcrypt (`bcryptjs`)** (Criptografia de senhas)
- **Dotenv (`dotenv`)** (Gerenciamento de variáveis de ambiente)

---

## Estrutura de Pastas

```text
librastech-desktop/
├── main/
│   ├── main.js          # Processo principal, janela Electron e handlers IPC
│   ├── preload.js       # Ponte segura (contextBridge) entre main e renderer
│   └── conexao.js       # Pool de conexão com o banco de dados MySQL
├── renderer/
│   ├── css/
│   │   └── estilos.css  # Identidade visual e estilos personalizados
│   ├── frmLogin.html    # Tela de autenticação
│   ├── frmLogin.js
│   ├── frmPrincipal.html # Dashboard administrativo com gráficos
│   ├── frmPrincipal.js
│   ├── frmMeusDados.html # Perfil e alteração de senha do administrador
│   ├── frmMeusDados.js
│   ├── frmUsuarios.html  # CRUD completo de usuários e controle de planos
│   └── frmUsuarios.js
├── schema.sql           # Script de criação das tabelas no MySQL
├── .env.example         # Modelo de variáveis de ambiente
├── package.json         # Dependências e configuração do instalador Windows
└── README.md            # Documentação do projeto